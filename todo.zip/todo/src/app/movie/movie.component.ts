import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { GenreService } from '../service/genre.service';
import { AddComponent } from '../add/add.component';

export class Movie {
  constructor(
    public id: number,
    public moviename: string,
    public moviedescription: string,
    public priceToWatch: number
  ) { }
}
export class Genre {

  constructor(
    public id: number,
    public gname: string,
    public movies: Movie[]
  ) { }
}



@Component({
  selector: 'app-movie',
  templateUrl: './movie.component.html',
  styleUrls: ['./movie.component.css']
})
export class MovieComponent implements OnInit {
  default: string;
  gObj: Genre;
  // Genres = [
  //   new Genre(1, 'Thriller',
  //     [new Movie(1, 'Dheena', 'Unexpected Climax', 450),
  //     new Movie(2, 'Viswasam', 'Family movie', 1050)]),

  //   new Genre(2, 'Action',
  //     [new Movie(3, 'Mankatha', 'Unexpected Climax', 450),
  //     new Movie(4, 'Aarambam', 'Family movie', 1050)]
  //   )
  //   // new Genre(3,'General',new Movie(3, 'Viswasam', 'Family movie', 1050)),
  //   // new Genre(4,'Action',new Movie(4, 'Dheena', 'Unexpected Climax', 450))

  // ]
  Genres: Genre[]
  Mov: Movie[]
  constructor(private genreService: GenreService, private router: Router) { }

  ngOnInit() {
    console.log(this.Genres);
    this.getAll();
  }




  getAll() {
    this.genreService.retrieveAll().subscribe(
      response => {
        console.log(response);
        this.Genres = response;
        for (let g1 of this.Genres) {
          if (this.gObj != null) {
            if (this.gObj.gname == g1.gname) {
              this.default = g1.gname;
              this.gObj = g1;
            }   
          }
        }
      }
    )
  }


 
  navigate(){
    this.router.navigateByUrl("/add");
  }

  updateMovie(val:any){
    this.router.navigateByUrl("/add/"+val);
  }

  deleteMovieById(movieId: number) {
    console.log(this.gObj.gname)
    this.genreService.deleteById(movieId).subscribe(
      response => {
        console.log(response);
        this.getAll();
      }
    );
  }

  onGenreSelected(val: any) {
    for (let g1 of this.Genres) {

      if (val == g1.gname) {
        this.gObj = g1;
      }
    }
  }

}
