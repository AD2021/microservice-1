import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core'; 
import { Genre, Movie } from '../movie/movie.component';
import { Observable } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class GenreService {

  constructor(
    private http:HttpClient
  ) { }


retrieveById(movieId:number){
  return this.http.get<Movie>(`http://localhost:8080/api/movies/${movieId}`);
}

retrieveAll()
{
    return this.http.get<Genre[]>('http://localhost:8080/api/genres');
}

deleteById(movieId:Number):Observable<any>{
  return this.http.delete(`http://localhost:8080/api/movies/${movieId}`);

}

updateMovieById(movieId:number, movie:Movie){
  return this.http.put(`http://localhost:8080/api/movies/${movieId}`,movie)
}


}