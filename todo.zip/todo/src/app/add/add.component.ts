import { Component, OnInit } from '@angular/core';
import { GenreService } from '../service/genre.service';
import { Movie } from '../movie/movie.component';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})

export class AddComponent implements OnInit {
  movie:Movie
  id:number
  constructor(
    private genreService :GenreService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit() {
    this.id = this.route.snapshot.params['id']
    this.movie = new Movie(1000,"","",null);
    console.log(this.id)
    if(this.id!=null){
    this.getbyId(this.route.snapshot.params['id']);
    }
  }

  getbyId(id:any){
    this.genreService.retrieveById(id).subscribe(
      data => {
        this.movie = data
        
      }
    )
  }

  save()
  {
    this.genreService.updateMovieById(this.id, this.movie).subscribe(
      data =>
      {console.log(data, "success")
      this.router.navigate(['movie'])
    }
    )
  }


}
